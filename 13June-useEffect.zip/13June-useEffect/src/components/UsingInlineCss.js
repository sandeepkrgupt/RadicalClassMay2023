
// Inline Css
const UsingInlineCss = () => {
    return (
        <div>
            <h1 style={{backgroundColor : 'yellow', fontSize : '14px', padding: '5px'}}>This is Heading TAg using inline Csss</h1>
        </div>
    )
}

export default UsingInlineCss;