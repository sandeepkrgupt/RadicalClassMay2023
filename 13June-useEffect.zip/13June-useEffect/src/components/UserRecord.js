
const UserRecord = (props) => {
    console.log('---', props.name);
    return (
        <div>
        {
            (props.name !== '') ? <h3>Now you are enrolled {props.name}. Your Enrollnment Number is - 23123</h3>
            : <h3>No Record Found</h3>
        }
        </div>
    )
}
export default UserRecord;