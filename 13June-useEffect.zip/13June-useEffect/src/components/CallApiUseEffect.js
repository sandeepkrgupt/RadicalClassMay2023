import { useEffect, useState } from "react";

// API Methods (fetch js methos | axios jquery library | async await js es6 method.)
const CallApiUseEffect = () => {
    const [postData, showData] = useState([]); // default value as array, because our data is array of objects.
    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(resp => resp.json())
            .then(json => showData(json))
            .catch(error => console.log(error))
    }, []);
    const getApiData = () => {
        console.log(data);
        
    }
    return (
        <div>
            <h1>Displaying API Data</h1>
            <button onClick={() => getApiData()}>Get Data</button>
            {
                postData.map(val => (
                    <ul style={{border: '1px solid black'}}>
                        <li>ID : {val.id}</li>
                        <li>Title : {val.title}</li>
                        <li>Details : {val.body}</li>
                    </ul>
                ))
            }
        </div>
    )
}

export default CallApiUseEffect;