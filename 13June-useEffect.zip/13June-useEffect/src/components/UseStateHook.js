
import { useState } from "react";

const UseStateHook = () => {
//        [variable_name, function_name] = useState(initial_value);
    const [value, IncreaseValue] = useState(0)
    const handleIncrement = () => {
        IncreaseValue(value + 1 );
    }
    return(
        <div>
        <h1>Number = {value}</h1>
        <button onClick={() => handleIncrement()}>++</button>
        </div>
    )
}

export default UseStateHook;