

const About = () =>{
    return (
        <div class="col-md-7 order-md-2">
            <h1>About Us</h1>
        <h2 class="featurette-heading fw-normal lh-1">Oh yeah, it’s that good. <span class="text-body-secondary">See for yourself.</span></h2>
        <p class="lead">Another featurette? Of course. More placeholder content here to give you an idea of how this layout would work with some actual real-world content in place.</p>
      </div>
    )
}

export default About;