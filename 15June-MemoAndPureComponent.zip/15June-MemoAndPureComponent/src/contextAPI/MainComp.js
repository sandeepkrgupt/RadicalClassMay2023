import Album from "./Album"
import Card from "./Card"
import Header from "./Header"

import { createContext, useState } from "react";
const ThemeContext = createContext();

const MainComp = () => {
    const [defaultTheme, setDefaultTheme] = useState('');
    return (
        <div>
            <button className="btn btn-primary" type="button" 
            style={{position: 'absolute',right: '10%',zIndex: '1',top: '8px'}}>
                <span>Apply Dark Theme</span>
            </button>
            <ThemeContext.Provider value={defaultTheme}>
                <div className="container">
                    <Header />
                    <Album />
                    <Card />
                </div>
            </ThemeContext.Provider>
        </div>

    )
}
export default MainComp;