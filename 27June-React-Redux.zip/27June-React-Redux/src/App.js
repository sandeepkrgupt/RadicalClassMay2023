import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import DisplayMessages from "./components/DisplayMsg";

function App() {
  return (
    <>
      <DisplayMessages />
    </>
  );
}

export default App;
