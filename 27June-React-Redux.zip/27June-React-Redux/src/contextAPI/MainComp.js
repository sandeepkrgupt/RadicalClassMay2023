import { createContext, useState } from "react";
import Album from "./Album"
import Card from "./Card"
import Header from "./Header"
import darkThemeClass from './darkTheme.module.css';
//export const variable_name = createContext() // to use context API Feature.
export const ThemeContext = createContext();

const MainComp = () => {
    const [defaultTheme, setDefaultTheme] = useState('');
    const setDarkTheme = () => {
        setDefaultTheme(darkThemeClass);
    }
    return (
        <>
            <button className="btn btn-primary" type="button" 
            style={{position: 'absolute',right: '10%',zIndex: '1',top: '8px'}}
            onClick={() => setDarkTheme()}>
                <span>Apply Dark Theme</span>
            </button>
            {/* Variable_name.Provider value={defaultTheme}  , Provider and value is predefined keyword*/}
            <ThemeContext.Provider value={defaultTheme}>
                <div className="container">
                    <Header />
                    <Album />
                    <Card />
                </div>
            </ThemeContext.Provider>
        </>
    )
}
export default MainComp;