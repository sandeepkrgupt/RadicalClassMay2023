import { useState } from "react";
const ManageStateLocally = () => {
    const [inputData, setInputData] = useState(); // input field
    const [messages, setMessages] = useState([]); //  message = ["milk","water","sugar","tea","leaf"]
    const handleChange = (e) => {
        const val = e.target.value;
        setInputData(val);
    }
    const submitMessage = () => {
        setMessages([...messages, inputData]);
        setInputData("");
    }
    return (
        <div>
            <h2>Type in a new Message:</h2>
            <input type="text"
                value={inputData} onChange={(e) => handleChange(e)} />
            <button type="button"
                onClick={() => submitMessage()}>click</button>
            <ul>
                {
                    messages.map((data, index) => <li key={index}>{data}</li>)
                }
            </ul>
        </div>
    );
};
export default ManageStateLocally;