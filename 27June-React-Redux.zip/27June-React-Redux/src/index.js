import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap';
import { Provider } from 'react-redux';
import { AddDataReducer } from './components/DisplayMsg';
import { createStore } from 'redux';

const root = ReactDOM.createRoot(document.getElementById('root'));
const reduxStore = createStore(AddDataReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
  serialize: true}));

root.render(
  <div>
    <Provider store={reduxStore}>
      <App />
    </Provider>
  </div>
);
