

import React from "react";
//import userData from './user-list.json';
import PassingDataUsingProps from "./PassingDataUsingProps";

class SimpleCounterClassComp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            count : 0,
            data: []
        }
    }
    incrementCount = () => {
        this.setState({
            count : this.state.count + 1
        })
    }
    static getDerivedStateFromProps(props, state) {
        if(this.props.name = 'abc') {
            this.setState({
                count : this.state.count + 1 
            })
        }
    }
    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then(resp => resp.json())
        .then(json => this.setState({data : json}))
        .catch(error => console.log(error))
    }
    componentDidUpdate() {

    }
    componentWillUnmount() {

    }
    
    decrementCount = () => {
        this.setState({
            count : this.state.count - 1
        })
    }
    render() {
        return (
            <div>
                <h1>{this.state.count}</h1>
                <button type="button" onClick={() => this.incrementCount()}>++</button>
                <button type="button" onClick={() => this.decrementCount()}>--</button>

                <div>
                    {/* we are passing userData with user defined property name data.*/}
                    <PassingDataUsingProps data = {this.props.userLists} myName="James" />
                </div>
            </div>

        )
    }
}

export default SimpleCounterClassComp;