

import React, { useState } from "react";
import { useDispatch } from "react-redux";

const initialState = {
    data: []
}

const ADDDATA = "ADDDATA"

const addDataAction = (newValue) => {
    console.log('-', newValue);
    return {
        type: ADDDATA,
        payload: newValue
    }
}

export const AddDataReducer = (state = initialState, action) => {
    switch (action.type) {
        case ADDDATA:
            return {
                ...state,
                data: [action.payload]
            }
        default:
            return state
    }
}

const DisplayMessages = () => {
    const dispatch = useDispatch();
    const [inputVal, setInputVal] = useState("");
    const [messages, setMsg] = useState([]);
    const submitMessage = () => {
        if (inputVal !== undefined && inputVal !== "") {
            console.log(inputVal);
            setMsg([...messages, inputVal]);
            console.log(messages);
            dispatch(addDataAction(messages));
            setInputVal("");
        } else {
            console.log("Please Enter Something")
        }
    }
    return (
        <div>
            <h2>Type in a new Message:</h2>
            <input
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)} />
            <br />
            <button
                onClick={() => submitMessage()} type="button">Submit</button>
            <ul>
                <h2>Your Data</h2>
                {messages.map((msg, index) => {
                    return (
                        <li key={index}>{msg}</li>
                    )
                })}
            </ul>
        </div>
    );
};
export default DisplayMessages;
