// action = when ever user perform any event, an action will be triggered.
const action = {
    type : "ADDPRODUCTTOCART",
    payload : {
        name:"smamsung galaxy note 2"
    }
}

// reducer = it is function which will have the logic to update your cart
const addToCartReducer = (state, action) => {
 // logic
}

// redux store, where the data or state of your entire app will be saved.
const store = Redux.createStore();
