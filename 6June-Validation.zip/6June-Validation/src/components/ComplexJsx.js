// ======== first way
// const html = (
//     <section>
//         <h1>Hello React</h1>
//         <p>html</p>
//         <ul>
//             <li>one</li>
//             <li>two</li>
//             <li>three</li>
//         </ul>
//     </section>
// )
// const ComplexJsx = () => {
//     return (
//        {html}
//     )
// }
// export default ComplexJsx;

//============second way

// function ComplexJsx() {
//     return (
//         <section>
//             <h1>Hello React</h1>
//             <p>html</p>
//             <ul>
//                 <li>one</li>
//                 <li>two</li>
//                 <li>three</li>
//             </ul>
//         </section>
//     )
// }
// export default ComplexJsx;
// ===== Third way functional components.

const ComplexJsx = () => {
    return (
        <section>
            <h1>Hello React</h1>
            <p>html</p>
            <ul>
                <li>one</li>
                <li>two</li>
                <li>three</li>
            </ul>
        </section>
    )
}
export default ComplexJsx;
