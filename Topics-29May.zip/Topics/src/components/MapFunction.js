
//const mobileList = ["Galagy Note 2", "Iphone 14 pro", "realme Note 2"];


import AnotherComp from './AnotherComp';
import MockData from './user-list.json';

const MapFunction = () => {
    return (
        <div>
            <h1>List of Mobiles</h1>
            <div>
                {
                    MockData.map(values => (
                        <ul key={values.id}>
                            <li>User ID : {values.userId}</li>
                            <li>ID : {values.id}</li>
                            <li>Title : {values.title}</li>
                            <li>Details: {values.body}</li>
                        </ul>
                    ))
                }
            </div>
            <AnotherComp />
        </div>
    )
}
export default MapFunction;