import logo from './logo.svg';
import './App.css';
import ComplexJsx from './components/ComplexJsx';
import MapFunction from './components/MapFunction';
import UsingInlineCss from './components/UsingInlineCss';
import UsingInternaCss from './components/UsingInternalCss';
import UsingExternalCss from './components/UsingExternalCss';
import JsClassComp from './components/JsClassComp';

//const html = <h1>Hello React</h1>
function App() {
  return (
    <div>
      {/* <ComplexJsx/>
    <MapFunction />
      <UsingInlineCss />
      <UsingInternaCss />
      <UsingExternalCss />*/}
      <JsClassComp />
    </div>
  );
}

export default App;
