
import { createStore } from "redux";
const Initialstate = {
    name : "John"
}
const action = {
    type : "SHOWNAME"
}
const nameReducer = (state = Initialstate, action) => {
    if(action.type == "SHOWNAME") {
        console.log(state);
    } else {
        console.log("Not Found")
    }
}
const store  = createStore();
console.log("name is =", store.getState())

