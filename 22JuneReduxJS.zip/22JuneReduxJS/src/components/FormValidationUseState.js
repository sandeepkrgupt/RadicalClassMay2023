

import { useState } from "react";
import UserRecord from "./UserRecord";
const FormValidationUseState = () => {
    // useState is predefined React Method to handle component state.
    const [userName, setUserName] = useState('');

    const [msg, showMsg] = useState('');

    const handleName = (event) => {
        setUserName(event.target.value);
    }
    const validateUserInput = () => {
        const regex = /^[a-z A-Z]*$/;
        if (regex.test(userName)) {
            document.getElementById("userName").style.border = "1px solid #777";
            showMsg("Hello Welcome " + userName);
        } else {
            document.getElementById("userName").style.border = "1px solid red";
            showMsg("No Record Found");
        }

    }
    console.log(msg);
    return (
        <form>
            <h3>Form VAlidation</h3>
            <input
                id="userName"
                type="text"
                value={userName}
                onChange={(e) => handleName(e)} />
            <button
                type="button"
                onClick={() => validateUserInput()}>Show Msg</button>
            <h1>{msg}</h1>
            {/* <UserRecord name={msg} /> */}
        </form>
    )
}

export default FormValidationUseState;