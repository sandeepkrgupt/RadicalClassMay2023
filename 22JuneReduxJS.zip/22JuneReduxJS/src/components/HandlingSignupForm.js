
import React from "react";

class HandlingSignupForm extends React.Component {
    constructor() {
        super();
        this.state = {
            name: '',
            email: '', // it shoud match email regex
            password: '', // check for length of paassword min 10 char
            contactNo: '', // regex for only numbrs with exact 10 length.
            states: '', // user has selected any state
            userData: []
        }
    }
    handleUserName = (e) => {
        const userName = e.target.value;
        const userNameRegex = /^[a-z A-Z]*$/;
        if (userNameRegex.test(userName)) {
            document.getElementById("user-name").style.border = "1px solid #777";
            document.getElementById("btn-submit").disabled = false;
            this.setState({
                name: userName
            })
        } else {
            document.getElementById("user-name").style.border = "1px solid red";
            document.getElementById("btn-submit").disabled = true;
            this.setState({
                name: userName
            })
        }
    }
    handleEmail = (e) => {
        const userMail = e.target.value;
        const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        if (emailRegex.test(userMail)) {
            document.getElementById("user-email").style.border = "1px solid #777";
            document.getElementById("btn-submit").disabled = false;
            this.setState({
                email: userMail
            })
        } else {
            document.getElementById("user-email").style.border = "1px solid red";
            document.getElementById("btn-submit").disabled = true;
            this.setState({
                email: userMail
            })
        }
    }
    handleState = (e) => {
        const stateName = e.target.value;
        if (stateName !== 'Select') {
            document.getElementById("user-state").style.border = "1px solid #777";
            document.getElementById("btn-submit").disabled = false;
            this.setState({
                states: stateName
            })
        } else {
            document.getElementById("user-state").style.border = "1px solid red";
            document.getElementById("btn-submit").disabled = true;
            this.setState({
                states: stateName
            })
        }

    }
    signup = () => {
        console.log(this.state.states)
        if (this.state.name !== '' && this.state.email !== '' && this.state.states !== '') {
            this.setState({
                userData: [this.state.name, this.state.email, this.state.states]
            })
        } else {
            this.setState({
                userData: ["Please Enter User Name and Password.", "Please Select State."]
            })
        }
    }
    render() {
        return (
            <form className="container">
                <div className="row">
                    <div className="col-sm-6">
                        <label>User Name</label>
                        <input type="text"
                            id="user-name"
                            className="form-control"
                            value={this.state.name}
                            onChange={(e) => this.handleUserName(e)} />
                    </div>
                    <div className="col-sm-6">
                        <label>Email</label>
                        <input type="text"
                            id="user-email"
                            className="form-control"
                            value={this.state.email}
                            onChange={(e) => this.handleEmail(e)} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>password</label>
                        <input type="text"
                            className="form-control"
                            value="" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>Contact Number</label>
                        <input type="text"
                            className="form-control"
                            value="" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>State</label>
                        <select type="text"
                            className="form-select"
                            id="user-state"
                            onChange={(e) => this.handleState(e)}>
                            <option>Select</option>
                            <option>MP</option>
                            <option>UP</option>
                        </select>
                    </div>
                </div>
                <button type="button"
                    id="btn-submit"
                    className="btn btn-success my-2"
                    onClick={() => this.signup()}>Signup</button>
                <h1>User Data</h1>
                <ul>
                    {
                        this.state.userData.map(i => <li>{i}</li>)
                    }
                </ul>
            </form>
        )
    }
}

export default HandlingSignupForm;