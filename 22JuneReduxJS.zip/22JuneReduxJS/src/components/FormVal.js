

import React from "react";
import './validation.css';


class FormValidation extends React.Component {
    constructor(props) {
        super();
        this.state = {
            email : '',
            password: '',
            myState: '',
            data : []
        }
    }   
    handleEmail(e) {
        let userEmail = e.target.value;
        let emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        if( userEmail !== '' && emailRegex.test(userEmail) === true) {
            this.setState({
                email : userEmail
            });
            document.getElementById("emailError").style.display = "none";
            document.getElementById("btnSubmit").disabled = false;
        } else {            
            this.setState({
                email : ''
            });
            document.getElementById("emailError").style.display = "block";
            document.getElementById("btnSubmit").disabled = true;
        }
    }


    handlePassword(e) {
        let userPassword = e.target.value;
        if(userPassword !== '' && userPassword.length > 5) {
            this.setState({
                password : userPassword
            });
          document.getElementById("passwordError").style.display = "none";
          document.getElementById("btnSubmit").disabled = false;


        } else {
            this.setState({
                password : ''
            });
         document.getElementById("passwordError").style.display = "block";
         document.getElementById("btnSubmit").disabled = true;
        }
    }
    handleStates(e) {
        let userState = e.target.value;
        if(userState === 'Choose') {
            document.getElementById("stateError").style.display = "block";  
            document.getElementById("btnSubmit").disabled = true;          
        } else {
            this.setState({
                myState : userState
            });
            document.getElementById("stateError").style.display = "none";
            document.getElementById("btnSubmit").disabled = false;
        }
    }
    handleSubmit(e)  {
        e.preventDefault();
    }
    render() {
        return (
            <>
                <form className="row g-3" onSubmit={(e) => this.handleSubmit(e)}>
                    <div className="col-md-6">
                        <label for="inputEmail4" className="form-label">Email</label>
                        <input type="email" className="form-control" id="inputEmail4" onChange={(e) => this.handleEmail(e)}/>
                        <span id="emailError" className="errorField">Please Enter a valid Email</span>
                    </div>
                    <div className="col-md-6">
                        <label for="inputPassword4" className="form-label">Password</label>
                        <input type="password" className="form-control" id="inputPassword4" onChange={(e) => this.handlePassword(e)}/>
                        <span id="passwordError" className="errorField">Please Enter a password with Minium 6 Character.</span>
                    </div>                
                    <div className="col-md-4">
                        <label for="inputState" className="form-label">State</label>
                        <select id="inputState" className="form-select" onChange={(e) => this.handleStates(e)}>
                            <option selected>Choose</option>
                            <option>MP</option>
                            <option>Maharastra</option>
                        </select>
                        <span id="stateError" className="errorField">Please Select a State.</span>
                    </div>  
                    <div className="col-12">
                        <button type="submit" className="btn btn-primary" id="btnSubmit">Sign in</button>
                    </div>
                </form>
                <div>
                    <h3>{this.state.email}</h3>
                </div>
            </>
        )
    }
}
export default FormValidation;