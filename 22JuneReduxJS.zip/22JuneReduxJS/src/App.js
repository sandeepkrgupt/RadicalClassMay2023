import { createStore } from "redux";
const Initialstate = { // initial values
  name: "John"
}

function App() {
  const nameAction = () => { // action creator
    return {
      type: "LOGIN",
      payload: null
    }
  }
  const nameReducer = (state = Initialstate, action) => { // reducer
    console.log(action.type)
    if (action.type === "LOGIN") {
      console.log("inside IF")
      return {
        name: "John Loged In Success"
      }
    } else {
      console.log("inside Else");
      return "Logged Failed!"
    }
  }
  //  nameofstore = createStore(nameoftheReducerFunction)
  const store = createStore(nameReducer); // store
  const showLogin = () => {
    store.dispatch(nameAction()); // dispatching action or action creator 
    console.log("name is =", store.getState()) //getState() use to access state value from store.
  }
 
  return (
    <div>
      <h1>Name</h1>
      <button type="button" onClick={() => showLogin()}>Login</button>
    </div>
  );
}

export default App;
