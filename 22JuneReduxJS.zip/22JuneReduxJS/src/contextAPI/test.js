const regex = /^\d{3}-\d{3}-\d{4}$/; // Match a phone number in the format XXX-XXX-XXXX
const phoneNumber = '123-456-7890';

console.log(regex.test(phoneNumber)); // Output: true