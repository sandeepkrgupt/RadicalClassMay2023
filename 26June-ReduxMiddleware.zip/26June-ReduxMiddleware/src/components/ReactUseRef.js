
import React , {useRef, useState} from "react";

const ReactUseRef = () => {
    const userNameInput = useRef(); // method is predefined react method.know as uncontrolled component.
    const [userNameValue, setUserNameValue] = useState('');// method is predefined react method.
    const handleName = () => {
        setUserNameValue(userNameInput.current.value);
    }
    console.log('Hi');
    return (
        <form>
        <h3>Form Validation = {userNameValue}</h3>
        <input
            id="userName"
            type="text"
            ref={userNameInput} // ref property is predefine.
            value={userNameValue}
            onChange={() => handleName()} />
    </form>
    )
}

export default ReactUseRef;
// validation is easy in controlled component , but not easy in uncontrolled 
//compoennts.
