

import React from "react";

class PassingDataUsingProps  extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>This is User Data.{this.props.myName}</h1>
                {
                    this.props.data.map( values => (
                        <ul>
                            <li>Title : {values.title}</li>
                            <li>Details : {values.body}</li>
                        </ul>
                    ))
                }
            </div>
        )
    }
}

export default PassingDataUsingProps;