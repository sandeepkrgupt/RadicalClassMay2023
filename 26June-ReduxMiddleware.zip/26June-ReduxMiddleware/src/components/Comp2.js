

import React from "react";
function Comp2(EncComp) {
    return function () {
        return (
            <div style={{ backgroundColor: "red", width: "400px" }}>
                This is from Higher Order Components.
                {/* <props.cmp /> */}
                <EncComp />
            </div>
        );
    };
}
export default Comp2;