

import React from "react";
import Comp2 from "./Comp2";

function ButtonComp(props) {
    const clickHandler = (e) => {
        console.log("Button has been clicked from Button Component.");
    }
    return (
        <button onClick={() => clickHandler()}>Click</button>
    );
}
//const EnhancedComponent = higherOrderComponent(WrappedComponent);
const EncComp = Comp2(ButtonComp);
export default EncComp;
