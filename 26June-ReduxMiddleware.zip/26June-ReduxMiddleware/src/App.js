import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";

function App() {
  const initialState = {
    dataFetchRequest: false,
    data: []
  }
  const REQUESTDATA = "REQUESTDATA";
  const RESPONSEDATA = "RESPONSEDATA";

  const requestForData = () => {
    return {
      type: REQUESTDATA
    }
  }
  const responseData = (userData) => {
    return {
      type: RESPONSEDATA,
      payload: userData
    }
  }

  const ApiReducer = (state = initialState, action) => {
    switch (action.type) {
      case REQUESTDATA:
        return {
          dataFetchRequest: true,
          payload: []
        }
      case RESPONSEDATA:
        return {
          dataFetchRequest: true,
          data: action.payload
        }
      default:
        return state
    }
  }
  const store = createStore(ApiReducer,
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
      serialize: true
    },
      applyMiddleware(thunk))
  );

  const handleApiCall = () => {
    store.dispatch(requestForData());
    console.log('--->', store.getState());
    // Side Effect
    fetch("https://jsonplaceholder.typicode.com/users")
      .then(resp => resp.json())
      .then(data => {
        console.log('Data -', data);
        store.dispatch(responseData(data)); // passing API response to responseData Action.
        console.log('====>', store.getState());
      })
      .catch(err => console.log(err));
  }
  return (
    <>
      <h1>Middleware</h1>
      <button onClick={() => handleApiCall()}>Call API</button>
    </>
  );
}

export default App;
