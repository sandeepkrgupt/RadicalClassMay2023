import { combineReducers, createStore } from "redux";

const Initialstate = { // initial values
  userActiveStatus: "User Not Active"
}
const initialCounter = {
  count: 0
}

function App() {
  // saving action type in variables
  const LOGINUSER = "LOGINUSER";
  const LOGOUTUSER = "LOGOUTUSER";
  const COUNTINCREASE = "COUNTINCREASE";

// creating the action function or action creators
  const loginUserAction = () => { // action creator
    return {
      type: LOGINUSER,
      payload: "John Miller"
    }
  }

  const logoutUserAction = () => {
    return {
      type: LOGOUTUSER,
      payload: "John Miller"
    }
  }
  
  const countIncrementAction = () => {
    return {
      type: COUNTINCREASE,
      payload: null
    }
  }

  const AuthReducer = (state = Initialstate, action) => { // reducer
    console.log(action.type);
    switch (action.type) {
      case LOGINUSER:
        return {
          userActiveStatus: "User Login Success",
          payload: action.payload
        }
      case LOGOUTUSER:
        return {
          userActiveStatus: "User Logout Success",
          payload: action.payload
        }
      default:
        return state
    }
  }

  const countReducer = (state = initialCounter, action) => {
    switch (action.type) {
      case COUNTINCREASE:
        return {
          count: state.count + 1
        }
      default:
        return state
    }
  }

  const oneReducer = combineReducers({
    auth: AuthReducer,
    count: countReducer
  });

  //  nameofstore = createStore(nameoftheReducerFunction)
  const store = createStore(oneReducer, 
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
    serialize: true})
  ); // store

  const loginUser = () => {
    store.dispatch(loginUserAction()); // dispatching action or action creator 
    console.log("name is =", store.getState()) //getState() use to access state value from store.
  }

  const logoutUser = () => {
    store.dispatch(logoutUserAction());
    console.log("user loggedout Success", store.getState());
  }

  const countIncrement = () => {
    store.dispatch(countIncrementAction());
    console.log("count =", store.getState());
  }
  return (
    <div>
      <h1>Name</h1>
      <button type="button" onClick={() => loginUser()}>Login</button>
      <button type="button" onClick={() => logoutUser()}>Logout</button>
      <button type="button" onClick={() => countIncrement()}>++</button>
    </div>
  );
}

export default App;
