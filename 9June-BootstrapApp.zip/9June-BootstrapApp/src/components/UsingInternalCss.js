
// Internal Css
const headingStyle = {
    backgroundColor : 'blue', 
    fontSize : '22px', 
    padding: '5px',
    color : '#fff'
}
const UsingInternaCss = () => {
    return(
        <div>
            <h1 style={headingStyle}>This is a Heading Tag Using Internal Css</h1>
        </div>
    )
}

export default UsingInternaCss;