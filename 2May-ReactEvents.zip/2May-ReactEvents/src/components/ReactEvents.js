
import React from "react";

class ReactEvents extends React.Component {
    constructor() {
        super();
        this.state = {
            textboxValue: '',
            displyData : ''
        }
    }
    handleTextVal = (event) => {
        console.log(event.target.value);
        this.setState({
            textboxValue: event.target.value
        })
    }
    handleData = () => {
        if(this.state.textboxValue !== '') {
            this.setState({
                displyData : this.state.textboxValue
            })
        } else {
            this.setState({
                displyData : 'Please Enter Value in Textbox.'
            })
        }
    }
    render() {
        return (
            <div>
                <h1>React Event</h1>
                <input type="text" value={this.state.textboxValue} onChange={(e) => this.handleTextVal(e)} />
                <button type="button" onClick={() => this.handleData()}>Show Data</button>
                <h2>Data onChange Event = {this.state.textboxValue}</h2>
                <br/>
                <h3>Data onClick Event = {this.state.displyData}</h3>
            </div>
        )
    }
}

export default ReactEvents;
