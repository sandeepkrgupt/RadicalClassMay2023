
import { Link, Outlet } from "react-router-dom";
const Navigation = () => {
    const space = {
        padding : '5px'
    }
    return (
        <div>
            <ul>
                <Link to="/" style={space}>Home</Link>
                <Link to="/about" style={space}>About</Link>
                <Link to="/contact" style={space}>Contact</Link>
            </ul>
            <Outlet />
        </div>
    )
}

export default Navigation;