import ImageSlider from "../components/ImageSlider";
import Product from "../components/Product";



const Home = () =>{
    return (
        <div>
            <ImageSlider />
            <Product />
        </div>
    )
}

export default Home;