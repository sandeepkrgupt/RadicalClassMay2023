import { memo } from "react";


const HelloWorld = (props) => {
    console.log('Hello', props);
    return (
        <div>
            <h1>Name = {props.userName}</h1>
            <h1>This is a Simple Component </h1>
            <p>This component is not having state or props</p>
        </div>
    )
}
const MemoComp = memo(HelloWorld); // MemoComp isuse defined variable.
export default MemoComp;
