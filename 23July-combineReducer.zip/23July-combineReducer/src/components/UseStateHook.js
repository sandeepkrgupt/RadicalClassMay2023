
import { useState } from "react";
import MemoComp from "./HelloWorld";


const UseStateHook = () => {
    const [value, IncreaseValue] = useState(0)
    const handleIncrement = () => {
        IncreaseValue(value + 1);
    }
    console.log('hi');
    return (
        <div>
            <h1>Number = {value}</h1>
            <button onClick={() => handleIncrement()}>++</button>
            <hr />
            <MemoComp userName="Rohit sharma" />
        </div>
    )
}

export default UseStateHook;