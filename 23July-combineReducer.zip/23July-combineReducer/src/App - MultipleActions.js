import { createStore } from "redux";
const Initialstate = { // initial values
  userActiveStatus: "User Not Active"
}

function App() {
  const LOGIN = "LOGINUSER";
  const LOGOUT = "LOGOUTUSER";

  const loginUserAction = () => { // action creator
    return {
      type: LOGIN,
      payload: "John Miller"
    }
  }
  const logoutUserAction = () => {
    return {
      type: LOGOUT,
      payload: "John Miller"
    }
  }
  const AuthReducer = (state = Initialstate, action) => { // reducer
    console.log(action.type);
    switch (action.type) {
      case LOGIN:
        return {
          userActiveStatus : "User Login Success",
          payload : action.payload
        }
      case LOGOUT:
        return {
          userActiveStatus : "User Logout Success",
          payload : action.payload
        }
      default:
        return state
    }
  }
  //  nameofstore = createStore(nameoftheReducerFunction)
  const store = createStore(AuthReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
    serialize: true})); // store
  const loginUser = () => {
    store.dispatch(loginUserAction()); // dispatching action or action creator 
    console.log("name is =", store.getState()) //getState() use to access state value from store.
  }
  const logoutUser = () => {
    store.dispatch(logoutUserAction());
    console.log("user loggedout Success", store.getState());
  }
  return (
    <div>
      <h1>Name</h1>
      <button type="button" onClick={() => loginUser()}>Login</button>
      <button type="button" onClick={() => logoutUser()}>Logout</button>
    </div>
  );
}

export default App;
