

import { useState } from "react";
import UserRecord from "./UserRecord";
const HandlingFormUsingUseState = () => {
    // useState is predefined React Method to handle component state.
    const [userName, setUserName] = useState('');

    const [ msg, showMsg] = useState('');

    const handleName = (event) => {
        setUserName(event.target.value);
    }
    const showNameWithMsg = () => {
        console.log(userName);
        showMsg("Hello Welcome " + userName) 
    }
    console.log(msg);
    return(
        <form>
            <h3>{userName}</h3>
            <input type="text" value={userName} onChange={(e) => handleName(e)} />
            <button type="button" onClick={() => showNameWithMsg()}>Show Msg</button>
            <h1>{msg}</h1>
            <UserRecord name={userName} />
        </form>
    )
}

export default HandlingFormUsingUseState;