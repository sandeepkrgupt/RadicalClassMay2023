import React from "react";
class JsClassComp extends React.Component {
    constructor() {
        super(); 
        this.state = {
            userName : "James Michelle"
        }        
        //this.userName = "James Michelle"
        // when ever we want to access the feature or members (variables, methods) of parent into child 
        // component when we have to call super();
    }

    correctUserName = () => {
        this.setState({
            userName : "James Camaroon"
        })
    }

    render() {
        return (
            <div>
                <h1>This is a class Component.<p>{this.state.userName}</p></h1>
                <button type="button" onClick={() => this.correctUserName()}>Change Name</button>
            </div>
        )
    }
}

export default JsClassComp;