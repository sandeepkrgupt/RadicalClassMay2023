
// External Css
import './style.css';
const UsingExternalCss = () => {
    return (
        <div>
            <h1 className='headingStyle'>This is a Heading Using External Css</h1>
        </div>
    )
}

export default UsingExternalCss;