

const AnotherComp = () => {
    return (<h1>Anothr Comp</h1>)
}

export default AnotherComp;