

import React from "react";

class ConditinalRendering extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        // (conditon) ? true block : false block; (Ternary Operator)
        return (
            <div>
                <h1>Conditional Rendering</h1>
                {
                    this.props.userLists.map(data => (
                        data.id % 2 === 0 ? (
                            <ul style={{ background: 'blue' }}>
                                <li>{data.id}</li>
                                <li>{data.title}</li>
                                <li>{data.body}</li>
                            </ul>) 
                            : 
                            (<ul style={{ background: 'green' }}>
                                <li>{data.id}</li>
                                <li>{data.title}</li>
                                <li>{data.body}</li>
                            </ul>)
                    ))
                }
                {/* WHEN WE NEED TO RENDER ONLY FOR TRUE CONDITION  */}
                {/* {
                    this.props.userLists.map(data => (
                        data.id % 2 === 0 && (
                            <ul style={{ background: 'blue' }}>
                                <li>{data.id}</li>
                                <li>{data.title}</li>
                                <li>{data.body}</li>
                            </ul>)
                    ))
                } */}
            </div>
        )
    }
}

export default ConditinalRendering;