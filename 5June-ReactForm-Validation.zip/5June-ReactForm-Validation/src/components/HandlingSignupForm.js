
import React from "react";

class HandlingSignupForm extends React.Component {
    constructor() {
        super();
        this.state = {
            name: '',
            email: '', // it shoud match email regex
            password: '', // check for length of paassword min 10 char
            contactNo: '', // regex for only numbrs with exact 10 length.
            states: '', // user has selected any state
            userData: []
        }
    }
    handleUserName = (e) => {
        const userName = e.target.value;
        const userNameRegex = /^[a-z A-Z]*$/;
        if (userNameRegex.test(userName)) {
            document.getElementById("user-name").style.border = "1px solid #777";
            this.setState({
                name: userName
            })
        } else {
            document.getElementById("user-name").style.border = "1px solid red";
            this.setState({
                name: userName
            })
        }
    }
    handleEmail = (e) => {
        const userMail = e.target.value;
        const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        if (emailRegex.test(userMail)) {
            document.getElementById("user-email").style.border = "1px solid #777";
            this.setState({
                email: userMail
            })
        } else {
            document.getElementById("user-email").style.border = "1px solid red";
            this.setState({
                email: userMail
            })
        }
    }
    handleState = (e) => {
        this.setState({
            states: e.target.value
        })
    }
    signup = () => {
        if (this.state.name !== '' && this.state.email !== '') {
            this.setState({
                userData: [this.state.name, this.state.email, this.state.states]
            })
        } else {
            this.setState({
                userData: ["Please Enter User Name and Password."]
            })
        }

    }
    render() {
        return (
            <form className="container">
                <div className="row">
                    <div className="col-sm-6">
                        <label>User Name</label>
                        <input type="text"
                            id="user-name"
                            className="form-control"
                            value={this.state.name}
                            onChange={(e) => this.handleUserName(e)} />
                    </div>
                    <div className="col-sm-6">
                        <label>Email</label>
                        <input type="text"
                            id="user-email"
                            className="form-control"
                            value={this.state.email}
                            onChange={(e) => this.handleEmail(e)} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>password</label>
                        <input type="text"
                            className="form-control"
                            value="" />
                    </div>

                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>Contact Number</label>
                        <input type="text"
                            className="form-control"
                            value="" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-sm-6">
                        <label>State</label>
                        <select type="text"
                            className="form-select"
                            onChange={(e) => this.handleState(e)}>
                            <option>Select</option>
                            <option>MP</option>
                            <option>UP</option>
                        </select>
                    </div>
                </div>
                <button type="button"
                    className="btn btn-success"
                    onClick={() => this.signup()}>Signup</button>
                <h1>User Data</h1>
                <ul>
                    {
                        this.state.userData.map(i => <li>{i}</li>)
                    }
                </ul>
            </form>
        )
    }
}

export default HandlingSignupForm;