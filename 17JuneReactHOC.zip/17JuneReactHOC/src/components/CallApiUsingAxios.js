

import { useEffect, useState } from "react";
import axios from "axios"; // it is jquery library to call promise(success or fail | accept or reject)
// API Methods (fetch js methos | axios jquery library | async await js es6 method.)
const CallApiUsingAxios = () => {
    const [postData, showData] = useState([]); // default value as array, because our data is array of objects.
    useEffect(() => {
        axios.get("https://jsonplaceholder.typicode.com/posts")
        .then(res => showData(res.data))
        .catch(err => console.log(err))
        }, []);

    return (
        <div>
            <h1>Displaying API Data</h1>
            {
                postData.map(val => (
                    <ul style={{border: '1px solid black'}}>
                        <li>ID : {val.id}</li>
                        <li>Title : {val.title}</li>
                        <li>Details : {val.body}</li>
                    </ul>
                ))
            }
        </div>
    )
}

export default CallApiUsingAxios;