import {createStore} from 'redux';
import todosReducer from './reducers/todosReducer';

const reduxStore = createStore(todosReducer,  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
  serialize: true}));

export default reduxStore;