import { ADD_TODO, TOGGLE_TODO, DELETE_TODO } from '../actions/actionTypes';

const initialState = [];

const todosReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TODO:
      return [
        ...state,
        action.payload
      ];
    case TOGGLE_TODO:
      //when ever you have to return function or JSX use return()
      return (
        state.map((todo) =>
          // condition ? true block : false block
          todo.id === action.payload ?
            { ...todo, completed: !todo.completed } : todo
        ));
    /* Filter Method
    const num = [1,2,3,22,44,12,0];
    const result = num.filter(val => val > 2);
    console.log(result); //[3, 22, 44, 12]
    */
    case DELETE_TODO:
      return (state.filter((todo) => todo.id !== action.payload));
    default:
      return state;
  }
};

export default todosReducer;