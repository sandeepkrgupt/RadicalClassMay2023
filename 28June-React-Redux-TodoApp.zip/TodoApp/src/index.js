// index.js
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import App from './App';
import reduxStore from './reduxStore';

render(
    <Provider store={reduxStore}>
        <h1>YOUR TODO LIST</h1>
        <App />
    </Provider>,
    document.getElementById('root')
);
