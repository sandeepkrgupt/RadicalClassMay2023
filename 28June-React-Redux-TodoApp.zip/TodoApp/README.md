A simple todo app that lets you add/delete todo items, mark items completed/pending, and browse items based on their completion status (all/completed/pending).

The app has been built using React and Redux. 

To run the app locally:
1. Clone this repository
2. Run npm install
3. Run npm start

Check the live app at https://aravindh-snr.github.io/react-redux-todo-app/
