import logo from './logo.svg';
import './App.css';
import ComplexJsx from './components/ComplexJsx';
import MapFunction from './components/MapFunction';
import UsingInlineCss from './components/UsingInlineCss';
import UsingInternaCss from './components/UsingInternalCss';
import UsingExternalCss from './components/UsingExternalCss';
import JsClassComp from './components/JsClassComp';
import SimpleCounterClassComp from './components/SimpleCounterClassComp';
import ConditinalRendering from './components/ConditinalRendering';
// JSON
import MockData from '../src/components/user-list.json';
//const html = <h1>Hello React</h1>
function App() {
  return (
    <div>
      {/* <ComplexJsx/>
    
      <UsingInlineCss />
      <UsingInternaCss />
      <UsingExternalCss />
      <JsClassComp />
      <SimpleCounterClassComp userLists = {MockData} />
      <MapFunction userLists = {MockData} />*/}
      <ConditinalRendering userLists = {MockData} />
    </div>
  );
}

export default App;
